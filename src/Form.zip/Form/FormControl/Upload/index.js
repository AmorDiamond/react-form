import React from 'react';

export default function Uplad() {
    return <div>Uplad</div>;
}
